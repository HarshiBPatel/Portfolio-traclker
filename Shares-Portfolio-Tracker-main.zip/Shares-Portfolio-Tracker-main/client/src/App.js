// import './App.css';
import MasterContainer from './containers/MasterContainer';

function App() {
  return (
    <>
      <MasterContainer />
    </>
  );
  }

export default App
