import React from 'react';

const Header = () => {
    return (
        <>    
            <h1>This is Our Main Header</h1>
            <h2>This could be a page title that changes</h2>
        </>
    )
}

export default Header;