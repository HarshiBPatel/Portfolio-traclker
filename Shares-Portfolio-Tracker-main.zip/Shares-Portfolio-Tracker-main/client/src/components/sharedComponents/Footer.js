import './Footer.css'
const Footer = () => {


    return ( 
        <>
        <footer className="footer">
            <div className="contributers">
            <p>Contributers</p>
            <p><a href="https://github.com/matthewmcfarlane">Matthew McFarlane</a></p>
            <p><a href="https://github.com/Boystavros">Sacha Ponniah</a></p>
            <p><a href="https://github.com/Minta-Ra">Raminta</a></p>
            </div>
        </footer>
        </>
     );
}
 
export default Footer;